ONLY PENAL HEADSHOT - Android Studio project

This project wraps the supplied offline practice dashboard in an Android WebView.
Features in the included app:
- Add and save practice projects
- View and delete saved projects
- Practice drills
- Sensitivity guide
- Local browser storage (on this device)

To build an APK:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the APK location.

Note: This is a fair-play practice companion. It does not connect to Free Fire,
modify game files, provide macros, auto-aim, or bypass anti-cheat systems.
