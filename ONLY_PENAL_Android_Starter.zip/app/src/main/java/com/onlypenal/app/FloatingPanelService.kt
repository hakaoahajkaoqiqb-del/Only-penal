package com.onlypenal.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: android.view.View? = null
    private var panel: android.view.View? = null
    private val channelId = "only_penal_overlay"

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(7, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "ONLY PENAL floating panel",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("ONLY PENAL is active")
                .setContentText("Tap the floating dot to open the panel")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("ONLY PENAL is active")
                .setContentText("Floating panel is active")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
    }

    private fun layoutParams(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 220
        }
    }

    private fun showBubble() {
        val dot = Button(this).apply {
            text = "OP"
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(35, 105, 220))
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = dot
        wm.addView(dot, layoutParams())
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(28, 28, 36))
        }
        val heading = TextView(this).apply {
            text = "ONLY PENAL"
            textSize = 18f
            setTextColor(Color.WHITE)
        }
        box.addView(heading)
        listOf("Sensitivity Guide", "DPI Guide", "FPS Info",
            "Voice: Normal", "Voice: Boy", "Voice: Girl",
            "Voice: Robot", "Voice: Deep").forEach { item ->
            val button = Button(this).apply {
                text = item
                setOnClickListener {
                    // UI-only demo: voice presets do not alter Free Fire's live microphone.
                    text = if (text.toString().endsWith(" ✓")) item else "$item ✓"
                }
            }
            box.addView(button)
        }
        val close = Button(this).apply {
            text = "CLOSE PANEL"
            setOnClickListener { hidePanel() }
        }
        box.addView(close)
        panel = box
        val params = layoutParams().apply {
            x = 90
            width = 680
        }
        wm.addView(box, params)
    }

    private fun hidePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { wm.removeView(it) }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_NOT_STICKY
}
