# ONLY PENAL — Android starter project

This is a starter Android Studio project containing:
- A permission-based floating bubble.
- A small panel with utility/voice-preset demo buttons.
- A notification while the floating panel service is active.

## Important voice-changer limitation
The voice buttons in this starter are **UI placeholders only**. They do not change the microphone audio sent by Free Fire or another app. Android normally does not let an ordinary third-party app intercept and replace another app's live microphone stream. Live game voice changing depends on device-level or game-level support; do not assume it will work.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. On the phone, allow "Display over other apps" when prompted.

For newer Android versions, foreground-service and notification behavior may require additional platform-specific adjustments.
